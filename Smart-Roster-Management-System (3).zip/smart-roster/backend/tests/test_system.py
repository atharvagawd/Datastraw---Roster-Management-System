import pytest
from datetime import date
from app import create_app, db
from app.models import Employee, Brand, Process, Pod, OperatingRule, PublicHoliday, LeaveRequest, RosterEntry, Conflict
from app.scheduler import validate_month, day_operates

@pytest.fixture
def app():
    app=create_app({'TESTING':True,'SQLALCHEMY_DATABASE_URI':'sqlite:///:memory:'})
    with app.app_context():
        db.create_all()
        pod=Pod(name='Test Pod',lead_name='Lead');p=Process(name='Customer Support',code='CS');b=Brand(name='Solo Brand');db.session.add_all([pod,p,b]);db.session.flush()
        e=Employee(employee_code='T001',name='Test User',email='test@example.com',pod_id=pod.id,weekly_off='Sunday');e.brands=[b];e.processes=[p];db.session.add(e);db.session.add(OperatingRule(brand_id=b.id,process_id=p.id,calendar='ALL_DAYS',min_staff=1,shift_start='09:00',shift_end='17:00'));db.session.commit()
        yield app
        db.session.remove();db.drop_all()

@pytest.fixture
def client(app): return app.test_client()

def test_health_and_crud(client):
    assert client.get('/api/health').status_code==200
    assert len(client.get('/api/employees').json)==1
    r=client.post('/api/brands',json={'name':'New Brand'});assert r.status_code==201
    assert client.put('/api/employees/1',json={'name':'Updated User'}).json['name']=='Updated User'
    assert client.delete('/api/employees/1').status_code==200

def test_generation_respects_sunday_off_and_covers_weekdays(app):
    with app.app_context():
        result=validate_month(2026,11);assert result['entries']>0
        assert RosterEntry.query.filter(RosterEntry.day==date(2026,11,1)).count()==0
        assert RosterEntry.query.filter(RosterEntry.day==date(2026,11,2)).count()==1

def test_single_resource_unavailability_creates_gap(app):
    with app.app_context():
        e=Employee.query.first();e.availability='Unavailable';db.session.commit();result=validate_month(2026,11)
        assert result['conflicts']>0
        assert Conflict.query.filter_by(kind='COVERAGE_GAP').count()>0

def test_public_holiday_calendar():
    from app.models import OperatingRule
    with app.app_context():
        rule=OperatingRule.query.first();rule.calendar='SUNDAYS_AND_HOLIDAYS_OFF';d=date(2026,11,14)
        assert day_operates(rule,d,{d}) is False
        rule.calendar='NO_PUBLIC_HOLIDAYS';assert day_operates(rule,d,{d}) is False
        rule.calendar='ALL_DAYS';assert day_operates(rule,d,{d}) is True

def test_leave_blocks_assignment(app):
    with app.app_context():
        e=Employee.query.first();db.session.add(LeaveRequest(employee_id=e.id,start_date=date(2026,11,2),end_date=date(2026,11,2),status='APPROVED'));db.session.commit();validate_month(2026,11)
        assert RosterEntry.query.filter_by(day=date(2026,11,2)).count()==0
